// SPDX-License-Identifier: MIT
pragma solidity ^0.8.13;

import "forge-std/Test.sol";
import {stdJson} from "forge-std/StdJson.sol";

/// @title GasReplayReal — اندازه‌گیری گس روی تراکنش‌های مشروع واقعی
/// @notice برای هر تراکنش مشروع واقعی (که اسکریپت scripts/fetch_legit_txs.py
/// از اتراسکن جمع کرده)، state دقیقاً قبل از آن تراکنش را فورک می‌کند و
/// همان فراخوانی را دوباره اجرا و گس آن را اندازه می‌گیرد. خروجی در
/// data/gas_real.csv نوشته می‌شود تا اسکریپت تحلیل میانگین/انحراف معیار را
/// حساب کند.
///
/// این همان چیزی است که مشکل «انحراف معیار صفر» را حل می‌کند: calldata
/// تراکنش‌های واقعی با هم فرق دارد و توزیع واقعی گس به دست می‌آید.
///
/// ورودی مورد انتظار data/legit_txs.json:
///   { "count": 3,
///     "txs": [ {"hash":"0x..","from":"0x..","to":"0x..","input":"0x.."}, ... ] }
///
/// اجرا:
///   forge test --match-path test/fork/GasReplayReal.t.sol -vv
contract GasReplayRealTest is Test {
    using stdJson for string;

    string constant OUT = "data/gas_real.csv";

    function test_ReplayLegitTxs_MeasureGas() public {
        string memory path = string.concat(vm.projectRoot(), "/data/legit_txs.json");
        if (!vm.exists(path)) {
            emit log_string("data/legit_txs.json not found; run scripts/fetch_legit_txs.py first.");
            vm.skip(true);
            return;
        }

        string memory json = vm.readFile(path);
        uint256 count = json.readUint(".count");

        vm.writeFile(OUT, "index,hash,gas_used,success\n");

        for (uint256 i = 0; i < count; i++) {
            string memory base = string.concat(".txs[", vm.toString(i), "]");

            // هر تراکنش: fork به state دقیقاً قبل از همان txHash
            bytes32 txHash = json.readBytes32(string.concat(base, ".hash"));
            address from = json.readAddress(string.concat(base, ".from"));
            address to = json.readAddress(string.concat(base, ".to"));
            bytes memory input = json.readBytes(string.concat(base, ".input"));

            vm.createSelectFork("mainnet", txHash);

            vm.prank(from);
            uint256 g0 = gasleft();
            (bool ok,) = to.call(input);
            uint256 used = g0 - gasleft();

            vm.writeLine(
                OUT,
                string.concat(
                    vm.toString(i), ",", vm.toString(txHash), ",", vm.toString(used), ",", ok ? "1" : "0"
                )
            );
            emit log_named_uint("gas used (tx index)", i);
            emit log_named_uint("  gas", used);
        }
        emit log_string("results written to data/gas_real.csv");
    }
}
