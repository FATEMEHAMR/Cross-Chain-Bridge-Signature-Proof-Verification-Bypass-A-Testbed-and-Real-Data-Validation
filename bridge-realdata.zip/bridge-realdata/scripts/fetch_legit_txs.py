#!/usr/bin/env python3
"""
جمع‌آوری تراکنش‌های مشروع واقعی به قرارداد Nomad Replica از Etherscan،
برای تست گس روی داده‌ی واقعی (test/fork/GasReplayReal.t.sol).

فقط تراکنش‌های موفقِ قبل از بلوک حمله که تابع process/proveAndProcess را
صدا زده‌اند نگه داشته می‌شوند.

خروجی: data/legit_txs.json  با شکل { "count": N, "txs": [ {hash,from,to,input}, ... ] }

اجرا (کلید در .env):
    export $(grep -v '^#' .env | xargs)   # لینوکس/مک
    python3 scripts/fetch_legit_txs.py
"""
import json
import os
import sys
import urllib.request
import urllib.parse

# Nomad Replica proxy
TARGET = "0x5D94309E5a0090b165FA4181519701637B6DAEBA"
# بلوک حمله ≈ 15259100؛ تراکنش‌های مشروع قبل از آن را می‌خواهیم
MAX_BLOCK = 15_259_000
# selector های process / proveAndProcess
WANTED_SELECTORS = {
    "0x928bc4b2",  # process(bytes) — در صورت تفاوت، با `cast sig` تأیید کنید
    "0x9a03636c",  # proveAndProcess(...) — نمونه؛ در صورت نیاز اصلاح کنید
}
LIMIT = int(os.environ.get("LEGIT_LIMIT", "50"))
OUT = os.path.join(os.path.dirname(__file__), "..", "data", "legit_txs.json")


def main():
    key = os.environ.get("ETHERSCAN_API_KEY")
    if not key:
        print("ETHERSCAN_API_KEY تنظیم نشده. .env را لود کنید.", file=sys.stderr)
        return 1

    params = {
        "module": "account",
        "action": "txlist",
        "address": TARGET,
        "startblock": "0",
        "endblock": str(MAX_BLOCK),
        "page": "1",
        "offset": "10000",
        "sort": "desc",
        "apikey": key,
    }
    url = "https://api.etherscan.io/api?" + urllib.parse.urlencode(params)
    print("دریافت لیست تراکنش‌ها از Etherscan ...")
    req = urllib.request.Request(url, headers={"User-Agent": "bridge-realdata/1.0"})
    resp = json.load(urllib.request.urlopen(req, timeout=60))

    if resp.get("status") != "1":
        print("پاسخ Etherscan:", resp.get("message"), resp.get("result"), file=sys.stderr)
        return 1

    txs = []
    for t in resp["result"]:
        if t.get("isError") == "1" or t.get("txreceipt_status") == "0":
            continue
        inp = t.get("input", "")
        if len(inp) < 10:
            continue
        sel = inp[:10].lower()
        # اگر مجموعه‌ی selector را خالی بگذارید، همه‌ی تراکنش‌های موفق می‌آیند
        if WANTED_SELECTORS and sel not in WANTED_SELECTORS:
            continue
        txs.append({"hash": t["hash"], "from": t["from"], "to": t["to"], "input": inp})
        if len(txs) >= LIMIT:
            break

    out = {"count": len(txs), "txs": txs}
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"{len(txs)} تراکنش مشروع نوشته شد → {os.path.relpath(OUT)}")
    if len(txs) == 0:
        print("هشدار: چیزی پیدا نشد. WANTED_SELECTORS را خالی کنید یا selector ها را "
              "با `cast sig 'process(bytes)'` تأیید کنید.")


if __name__ == "__main__":
    sys.exit(main())
