#!/usr/bin/env python3
"""
فاز A — ساخت دیتاست واقعی حوادث پل از API عمومی DefiLlama.

خروجی: data/incidents_raw.csv
سپس ستون‌های زیرنوع/STRIDE/CCF را دستی تکمیل کنید (طبق فصل ۳).

اجرا:
    python3 scripts/fetch_incidents.py
"""
import json
import csv
import os
import sys
import urllib.request
import datetime as dt

HACKS_URL = "https://api.llama.fi/hacks"

# معیار IC4: بازه‌ی زمانی مطابق تصمیم روش‌شناختی فصل ۳
START = dt.datetime(2021, 3, 1)
END = dt.datetime(2023, 12, 31)

OUT = os.path.join(os.path.dirname(__file__), "..", "data", "incidents_raw.csv")


def to_date(d):
    if isinstance(d, (int, float)):
        return dt.datetime.utcfromtimestamp(d)
    return dt.datetime.fromisoformat(str(d)[:10])


def main():
    print(f"دریافت از {HACKS_URL} ...")
    req = urllib.request.Request(HACKS_URL, headers={"User-Agent": "bridge-realdata/1.0"})
    data = json.load(urllib.request.urlopen(req, timeout=60))
    print(f"کل رکوردها: {len(data)}")

    rows = []
    for h in data:
        if not h.get("bridgeHack"):
            continue
        try:
            d = to_date(h["date"])
        except Exception:
            continue
        if not (START <= d <= END):
            continue
        rows.append(
            {
                "date": d.date().isoformat(),
                "name": h.get("name", ""),
                "amount_usd": h.get("amount", ""),
                "chains": ";".join(h.get("chain") or []),
                "classification": h.get("classification", ""),
                "technique": h.get("technique", ""),
                "source": h.get("source", ""),
                # ستون‌های زیر را دستی طبق فصل ۳ پر کنید:
                "INC_ID": "",
                "subtype": "",          # Forgery / Replay / WrongMessage
                "stride": "",           # مثلا S,T
                "ccf_component": "",     # Debt Issuer / Custodian / ...
                "rekt_url": "",
                "slowmist_url": "",
                "postmortem_url": "",
                "has_poc": "",          # DeFiHackLabs? yes/no + مسیر
                "include_decision": "",  # IC1..IC4 → in/out + دلیل
            }
        )

    rows.sort(key=lambda r: r["date"])
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    print(f"{len(rows)} حادثه‌ی پل در بازه نوشته شد → {os.path.relpath(OUT)}")
    print("گام بعد: ستون‌های subtype/stride/ccf/has_poc/include_decision را دستی تکمیل کنید.")


if __name__ == "__main__":
    sys.exit(main())
