#!/usr/bin/env python3
"""
تحلیل آماری گس از خروجی test/fork/GasReplayReal.t.sol.

ورودی: data/gas_real.csv  (index,hash,gas_used,success)
خروجی: چاپ میانگین، انحراف معیار، میانه، کمینه، بیشینه روی ترمینال
        و نوشتن data/gas_summary.csv

اجرا:
    python3 scripts/analyze_gas.py
"""
import csv
import os
import statistics as st

IN = os.path.join(os.path.dirname(__file__), "..", "data", "gas_real.csv")
OUT = os.path.join(os.path.dirname(__file__), "..", "data", "gas_summary.csv")


def main():
    if not os.path.exists(IN):
        print(f"{IN} پیدا نشد. ابتدا GasReplayReal.t.sol را اجرا کنید.")
        return 1

    vals = []
    with open(IN, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row.get("success") == "1":
                vals.append(int(row["gas_used"]))

    if not vals:
        print("هیچ تراکنش موفقی در CSV نبود.")
        return 1

    summary = {
        "n": len(vals),
        "mean": round(st.mean(vals), 2),
        "stdev": round(st.pstdev(vals), 2) if len(vals) > 1 else 0.0,
        "median": st.median(vals),
        "min": min(vals),
        "max": max(vals),
    }
    for k, v in summary.items():
        print(f"{k:8s}: {v}")

    with open(OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(summary.keys()))
        w.writeheader()
        w.writerow(summary)
    print(f"خلاصه نوشته شد → {os.path.relpath(OUT)}")


if __name__ == "__main__":
    raise SystemExit(main())
